//B.Sankeerthana 1602-19-737-099 ITS VACAY TIME TOUR MANAGEMENT SYSTEM
package TMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;
import java.util.StringTokenizer;

public class hotels 
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_htl_name,JL_htl_id,JL_noOfRooms,JL_st_id;
	private JTextField JTF_st_id,JTF_htl_name,JTF_htl_id,JTF_noOfRooms;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert3,update3,view3,delete3;
	private List hotelsList;
	private Choice stateId,hotelId;
	
	public hotels(JPanel pn,JFrame jframe,JMenuItem insert3,JMenuItem update3,JMenuItem view3,JMenuItem delete3)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert3=insert3;
		this.update3=update3;
		this.view3=view3;
		this.delete3=delete3;
		
		JL_st_id=new JLabel("State_Id:");
		JTF_st_id=new JTextField(10);
		JL_htl_id=new JLabel("Hotel Id:");
		JTF_htl_id=new JTextField(10);
		JL_htl_name=new JLabel("Hotel Name:");
        JTF_htl_name=new JTextField(10);
        JL_noOfRooms=new JLabel("No Of Rooms:");
        JTF_noOfRooms=new JTextField(10);
       
        this.pn=pn;
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","it19737099","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadStatesHotels()
	{
		try
		{
			hotelsList=new List();
			hotelsList.removeAll();
			rs=stmt.executeQuery("select * from Hotels");
			while(rs.next()) 
			{
				//hotelsList.add(rs.getString("hotel_Id")+"->"+rs.getString("state_Id"));
				hotelsList.add(rs.getString("hotel_Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadStates()
	{
		try
		{
			stateId=new Choice();
			stateId.removeAll();
			rs=stmt.executeQuery("select * from States");
			while(rs.next()) 
			{
				stateId.add(rs.getString("state_Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadHotels()
	{
		try
		{
			hotelId=new Choice();
			hotelId.removeAll();
			rs=stmt.executeQuery("select * from Hotels");
			while(rs.next()) 
			{
				hotelId.add(rs.getString("hotel_Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void buildGUI()
	{
		insert3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				
				JTF_st_id.setText(null);
				JTF_htl_id.setText(null);
				JTF_htl_name.setText(null);
				JTF_noOfRooms.setText(null);
				
				loadStates();
				loadHotels();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_st_id);
				pn1.add(JTF_st_id);
				pn1.add(JL_htl_id);
				pn1.add(JTF_htl_id);
				pn1.add(JL_htl_name);
				pn1.add(JTF_htl_name);
				pn1.add(JL_noOfRooms);
				pn1.add(JTF_noOfRooms);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				
				pn2=new JPanel(new FlowLayout());
				hotelsList=new List(10);
				loadStatesHotels();
				pn2.add(hotelsList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				//hotelsList.setEnabled(false);
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO Hotels VALUES("+ JTF_htl_id.getText() + ","
							+ "'" +JTF_htl_name.getText() +"'," +JTF_noOfRooms.getText()+","
							+""+JTF_st_id.getText() +")";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadStatesHotels();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		update3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_st_id.setText(null);
				JTF_htl_id.setText(null);
				JTF_htl_name.setText(null);
				JTF_noOfRooms.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_st_id);
				pn1.add(JTF_st_id);
				pn1.add(JL_htl_id);
				pn1.add(JTF_htl_id);
				pn1.add(JL_htl_name);
				pn1.add(JTF_htl_name);
				pn1.add(JL_noOfRooms);
				pn1.add(JTF_noOfRooms);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				
				pn2=new JPanel(new FlowLayout());
				hotelsList=new List(10);
				loadStatesHotels();
				pn2.add(hotelsList);
				pn2.setBounds(250,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				hotelsList.addItemListener(new ItemListener() {
					@Override
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from Hotels");
							while (rs.next()) 
							{
								if (rs.getString("hotel_id").equals(hotelsList.getSelectedItem()))
									break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_htl_id.setText(rs.getString("hotel_Id"));
								JTF_htl_name.setText(rs.getString("hotel_Name")); 
								JTF_noOfRooms.setText(rs.getString("no_Of_Rooms_Available"));
								JTF_st_id.setText(rs.getString("state_Id"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							int a=JOptionPane.showConfirmDialog(pn1,"Are you sure do you want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String rooms=JOptionPane.showInputDialog(pn,"Enter New No Of Rooms:");
								JTF_noOfRooms.setText(rooms);
								String query="update Hotels set no_Of_Rooms_Available='"+rooms+
										"' where hotel_Id="+JTF_htl_id.getText();

								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows successfully");
								loadStatesHotels();
							}
						}
						catch(SQLException exp)
						{
							displaySQLErrors(exp);
						}
					}
				});
			}
		});
		
		delete3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");
				
				JTF_st_id.setText(null);
				JTF_htl_id.setText(null);
				JTF_htl_name.setText(null);
				JTF_noOfRooms.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_st_id);
				pn1.add(JTF_st_id);
				pn1.add(JL_htl_id);
				pn1.add(JTF_htl_id);
				pn1.add(JL_htl_name);
				pn1.add(JTF_htl_name);
				pn1.add(JL_noOfRooms);
				pn1.add(JTF_noOfRooms);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(180,350,75,35);

				pn2=new JPanel(new FlowLayout());
				hotelsList=new List(10);
				loadStatesHotels();
				pn2.add(hotelsList);
				pn2.setBounds(250,350,300,180);  
							
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				hotelsList.addItemListener(new ItemListener() {
					@Override
					public void itemStateChanged(ItemEvent e)
					{
						try 
						{
							rs=stmt.executeQuery("select * from Hotels");
							StringTokenizer st=new StringTokenizer(hotelsList.getSelectedItem());
							//String p=st.nextToken();
							String q=st.nextToken();
											
							while (rs.next()) 
							{													
								//if (rs.getString("state_Id").equals(p) && rs.getString("hotel_Id").equals(q))
								if (rs.getString("hotel_Id").equals(q))
								  break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_htl_id.setText(rs.getString("hotel_Id"));
								JTF_htl_name.setText(rs.getString("hotel_Name"));
								JTF_noOfRooms.setText(rs.getString("no_Of_Rooms_Available"));
								JTF_st_id.setText(rs.getString("state_Id"));

							}
						}
						catch (SQLException selectException) 
						{
								displaySQLErrors(selectException);
						}
					}
				});
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure do you want to delete:");
							if(a==JOptionPane.YES_OPTION)
							 {  
								 StringTokenizer st=new StringTokenizer(hotelsList.getSelectedItem(),"->");
								 String query="DELETE FROM Hotels WHERE hotel_Id="+st.nextToken();
							     int i=stmt.executeUpdate(query);
								 JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows successfully");
								 loadStatesHotels();
							 }
						 }
						 catch(SQLException exp)
						 {
							 displaySQLErrors(exp);
						 }
					}
				});
			}
		});
		view3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JB_view=new JButton("View");
				JLabel view=new JLabel("Hotels View");
				Font myFont = new Font("Serif",Font.BOLD,50);
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn.add(pn1);
				pn.add(pn2);
				pn.setLayout(new FlowLayout());
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("Hotels Details");     
					    JTable jt;       
					    DefaultTableModel model = new DefaultTableModel(); 
					    
					    jt= new JTable(model); 
					    model.addColumn("Hotel Id");
					    model.addColumn("Hotel Name");
					    model.addColumn("No Of Rooms");	
					    model.addColumn("State Id");
					    
					    try 
					    {
							rs=stmt.executeQuery("select * from Hotels");
							while(rs.next()) 
							{
								 model.addRow(new Object[]{rs.getString("hotel_Id"), 
								rs.getString("hotel_Name"),rs.getString("no_Of_Rooms_Available")
								,rs.getString("state_Id")});
							}
						}
						catch(SQLException exp) 
					    {
							displaySQLErrors(exp);
					    }
					    jt.setEnabled(false);
				        jt.setBounds(30, 40, 180, 150); 
					    JScrollPane sp = new JScrollPane(jt);
					    jf.add(sp); 
					    jf.setSize(800, 400); 
					    jf.setVisible(true);        
					}
				});
			}
		});
	}        
}
