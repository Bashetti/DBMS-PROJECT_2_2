//B.Sankeerthana 1602-19-737-099 ITS VACAY TIME TOUR MANAGEMENT SYSTEM
package TMS;
import java.awt.*;
import javax.swing.*;
public class TMSUI extends JFrame
{
	private JPanel Jpn0,Jpn1;
    private JMenuBar mbar;
    private JMenu states,places,hotels,customers,payments,selects,statesAvailable;
    private JMenuItem insert1,update1,view1,delete1;
    private JMenuItem insert2,update2,view2,delete2;
    private JMenuItem insert3,update3,view3,delete3;
    private JMenuItem insert4,update4,view4,delete4;
    private JMenuItem insert5,update5,view5,delete5;
    private JMenuItem insert6,update6,view6,delete6;
    private JMenuItem s1,s2,s3,s4,s5;

    private JLabel labelName;
    
    public void defineComponents()
    {
    	Jpn0=new JPanel();
    	Jpn1=new JPanel();
    	
    	mbar=new JMenuBar();
    	
    	statesAvailable=new JMenu("List Of States Available");
    	states=new JMenu("States");
    	places=new JMenu("Places");
    	hotels=new JMenu("Hotels");
    	customers=new JMenu("Customers");
    	payments=new JMenu("Payments");
    	selects=new JMenu("Selects");
    	
    	labelName=new JLabel("It's Vacay Time-Tour Management System"); 	
    }
    public void addComponents()
    {
    	add(Jpn0);
    	Jpn1.add(labelName);
    	Jpn1.setAlignmentY(CENTER_ALIGNMENT);
    	Jpn1.setBounds(500,500,800,100);
    	Jpn0.add(Jpn1);
    	
    	setJMenuBar(mbar);
    	
    	mbar.add(statesAvailable);
    	mbar.add(states);
    	mbar.add(places);
    	mbar.add(hotels);
    	mbar.add(customers);
    	mbar.add(payments);
    	mbar.add(selects);
    	
    	statesAvailable.add(s1=new JMenuItem("Goa"));
    	statesAvailable.add(s2=new JMenuItem("Kerala"));
    	statesAvailable.add(s3=new JMenuItem("Telangana"));
    	statesAvailable.add(s4=new JMenuItem("Maharashtra"));
    	statesAvailable.add(s5=new JMenuItem("Uttar Pradesh"));

    	states.add(insert1=new JMenuItem("Insert"));
    	states.add(update1=new JMenuItem("Update"));
    	states.add(view1=new JMenuItem("View"));
    	states.add(delete1=new JMenuItem("Delete"));
    	
    	places.add(insert2=new JMenuItem("Insert"));
    	places.add(update2=new JMenuItem("Update"));
    	places.add(view2=new JMenuItem("View"));
    	places.add(delete2=new JMenuItem("Delete"));
    	
    	hotels.add(insert3=new JMenuItem("Insert"));
    	hotels.add(update3=new JMenuItem("Update"));
    	hotels.add(view3=new JMenuItem("View"));
    	hotels.add(delete3=new JMenuItem("Delete"));
    	
    	customers.add(insert4=new JMenuItem("Insert"));
    	customers.add(update4=new JMenuItem("Update"));
    	customers.add(view4=new JMenuItem("View"));
    	customers.add(delete4=new JMenuItem("Delete"));
    	
    	payments.add(insert5=new JMenuItem("Insert"));
    	payments.add(update5=new JMenuItem("Update"));
    	payments.add(view5=new JMenuItem("View"));
    	payments.add(delete5=new JMenuItem("Delete"));
    	
    	selects.add(insert6=new JMenuItem("Insert"));
    	selects.add(update6=new JMenuItem("Update"));
    	selects.add(view6=new JMenuItem("View"));
    	selects.add(delete6=new JMenuItem("Delete"));

    }
    public void registerComponents()
    {
    	states obj_states=new states(Jpn0,TMSUI.this,insert1,update1,view1,delete1);
    	obj_states.buildGUI();
    	places obj_places=new places(Jpn0,TMSUI.this,insert2,update2,view2,delete2);
    	obj_places.buildGUI();
    	hotels obj_hotels=new hotels(Jpn0,TMSUI.this,insert3,update3,view3,delete3);
    	obj_hotels.buildGUI();
    	customers obj_customers=new customers(Jpn0,TMSUI.this,insert4,update4,view4,delete4);
    	obj_customers.buildGUI();
    	payments obj_payments=new payments(Jpn0,TMSUI.this,insert5,update5,view5,delete5);
    	obj_payments.buildGUI();
    	selects obj_selects=new selects(Jpn0,TMSUI.this,insert6,update6,view6,delete6);
    	obj_selects.buildGUI();
    }
	public TMSUI()
	{
		defineComponents();
		addComponents();
		registerComponents();
		setSize(400,500);
		setBackground(Color.GRAY);
		setVisible(true);
		setTitle("IT'S VACAY TIME-TOUR MANAGEMENT SYSTEM");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
