//B.Sankeerthana 1602-19-737-099 ITS VACAY TIME TOUR MANAGEMENT SYSTEM
package TMS;
public class Main 
{
	public static void main(String []args)
	{
		new TMSUI();
	}
}
