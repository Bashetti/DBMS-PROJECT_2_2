//B.Sankeerthana 1602-19-737-099 ITS VACAY TIME TOUR MANAGEMENT SYSTEM
package TMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;
import java.util.StringTokenizer;

public class payments 
{
	private JPanel pn1,pn2,pn3,pn;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_pay_id,JL_cost,JL_cus_id,JL_rating;
	private JTextField JTF_pay_id,JTF_cost,JTF_cus_id,JTF_rating;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert5,update5,view5,delete5;
	private List paymentList;
	private Choice cusId,payId;
	public payments(JPanel pn,JFrame jframe,JMenuItem insert5,JMenuItem update5,JMenuItem view5,JMenuItem delete5)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert5=insert5;
		this.update5=update5;
		this.view5=view5;
		this.delete5=delete5;
		
		JL_pay_id=new JLabel("Payment_Id:");
		JTF_pay_id=new JTextField(10);
		JL_cost=new JLabel("Cost:");
		JTF_cost=new JTextField(10);
		JL_rating=new JLabel("Rating:");
		JTF_rating=new JTextField(10);
		JL_cus_id=new JLabel("Customer Id:");
		JTF_cus_id=new JTextField(10);
                
        this.pn=pn;
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","it19737099","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadCustomersPayments()
	{
		try
		{
			paymentList=new List();
			paymentList.removeAll();
			rs=stmt.executeQuery("select * from Payments");
			while(rs.next()) 
			{
				paymentList.add(rs.getString("payment_Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}

	public void loadCustomers()
	{
		try
		{
			cusId=new Choice();
			cusId.removeAll();
			rs=stmt.executeQuery("select * from Customers");
			while(rs.next()) 
			{
				cusId.add(rs.getString("customer_Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	
	public void loadPayments()
	{
		try
		{
			payId=new Choice();
			payId.removeAll();
			rs=stmt.executeQuery("select * from Payments");
			while(rs.next()) 
			{
				payId.add(rs.getString("payment_Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	
	public void buildGUI()
	{
		insert5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				
				JTF_pay_id.setText(null);
				JTF_cost.setText(null);
				JTF_rating.setText(null);
				JTF_cus_id.setText(null);
				
				loadCustomers();
				loadPayments();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_pay_id);
				pn1.add(JTF_pay_id);
				pn1.add(JL_cost);
				pn1.add(JTF_cost);
				pn1.add(JL_rating);
				pn1.add(JTF_rating);
				pn1.add(JL_cus_id);
				pn1.add(JTF_cus_id);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				paymentList=new List(10);
				loadCustomersPayments();
				pn2.add(paymentList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);

				paymentList.setEnabled(false);
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO Payments VALUES(" + JTF_pay_id.getText() + ","
							 +JTF_cost.getText() +"," +JTF_rating.getText() +","+JTF_cus_id.getText()+")";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadCustomersPayments();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
		update5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
			
				JTF_pay_id.setText(null);
				JTF_cost.setText(null);
				JTF_rating.setText(null);
				JTF_pay_id.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
						
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_pay_id);
				pn1.add(JTF_pay_id);
				pn1.add(JL_cost);
				pn1.add(JTF_cost);
				pn1.add(JL_rating);
				pn1.add(JTF_rating);
				pn1.add(JL_cus_id);
				pn1.add(JTF_cus_id);
						
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				
				pn2=new JPanel(new FlowLayout());
				paymentList=new List(10);
				loadCustomersPayments();
				pn2.add(paymentList);
				pn2.setBounds(250,350,300,180);  
						
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();

				paymentList.addItemListener(new ItemListener()
				{
					public void itemStateChanged(ItemEvent e) 
					{
						try 
						{
							rs=stmt.executeQuery("select * from Payments");					
							while (rs.next()) 
							{
								if (rs.getString("payment_Id").equals(paymentList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_pay_id.setText(rs.getString("payment_Id"));
								JTF_cost.setText(rs.getString("cost"));
								JTF_rating.setText(rs.getString("rating"));
								JTF_cus_id.setText(rs.getString("customer_Id"));
							}
						} 
						catch (SQLException exp) 
						{
							displaySQLErrors(exp);
						}
					}
				});	
				
				JB_modify.addActionListener(new ActionListener() {
					 @Override
					 public void actionPerformed(ActionEvent e) { 
					 try 
					 {
						int a=JOptionPane.showConfirmDialog(pn1,"Are you sure do you want to update:");
						if(a==JOptionPane.YES_OPTION)
						{  
							String rating=JOptionPane.showInputDialog(pn,"Enter rating:");
							JTF_rating.setText(rating);
							String query="update Payments set rating='"+rating+
									"' where payment_Id="+JTF_pay_id.getText();
							int i=stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows successfully");
							loadCustomersPayments();
						}
			 		}
					catch(SQLException exp)
				 	{
						displaySQLErrors(exp);
					}
				 }	
				});
			}
		 });
			delete5.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent aevt)
				{
					JB_delete=new JButton("Delete");
								
					JTF_pay_id.setText(null);
					JTF_cost.setText(null);
					JTF_rating.setText(null);
					JTF_pay_id.setText(null);
																
					pn.removeAll();
					jframe.invalidate();
					jframe.validate();
					jframe.repaint();
								
					pn1=new JPanel();
					pn1.setLayout(new GridLayout(10,10));
					pn1.add(JL_pay_id);
					pn1.add(JTF_pay_id);
					pn1.add(JL_cost);
					pn1.add(JTF_cost);
					pn1.add(JL_rating);
					pn1.add(JTF_rating);
					pn1.add(JL_cus_id);
					pn1.add(JTF_cus_id);
																
					pn3=new JPanel(new FlowLayout());
					pn3.add(JB_delete);
					pn1.setBounds(115,80,300,250);
					pn3.setBounds(200,350,75,35);
								 
					pn2=new JPanel(new FlowLayout());
					paymentList=new List(10);
					loadCustomersPayments();
					pn2.add(paymentList);
					pn2.setBounds(250,350,300,180);
					
					pn.add(pn1);
					pn.add(pn3);
					pn.add(pn2);
								
					pn.setLayout(new BorderLayout());
					jframe.add(pn);
					jframe.setSize(800,800);
					jframe.validate();
					
					paymentList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=stmt.executeQuery("select * from Payments");
								StringTokenizer st=new StringTokenizer(paymentList.getSelectedItem());
								String q=st.nextToken();
												
								while (rs.next()) 
								{													
									if (rs.getString("payment_Id").equals(q))
												break;
								}
								if (!rs.isAfterLast()) 
								{
									JTF_pay_id.setText(rs.getString("payment_Id"));
									JTF_cost.setText(rs.getString("cost"));
									JTF_rating.setText(rs.getString("rating"));
									JTF_cus_id.setText(rs.getString("customer_Id"));								}
							}
							catch (SQLException selectException) 
							{
									displaySQLErrors(selectException);
							}
						}
					});	
					JB_delete.addActionListener(new ActionListener() {
					 @Override
					 public void actionPerformed(ActionEvent e) 
					 { 
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure do you want to delete:");
							if(a==JOptionPane.YES_OPTION)
							 {  
								 StringTokenizer st=new StringTokenizer(paymentList.getSelectedItem(),"->");
								 String query="DELETE FROM Payments WHERE payment_Id="+st.nextToken();
							     int i=stmt.executeUpdate(query);
								 JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows succesfully");
								 loadCustomersPayments();
							 }
						 }
						 catch(SQLException exp)
						 {
							 displaySQLErrors(exp);
						 }
						}
					});
				}
			});
			view5.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						pn.removeAll();
						jframe.invalidate();
						jframe.validate();
						jframe.repaint();
								
						
						JLabel view=new JLabel("Payments View");
						JB_view=new JButton("View");
						Font myFont = new Font("Serif",Font.BOLD,50);
						view.setFont((myFont));
						
						pn1=new JPanel();
						pn2=new JPanel();
						pn1.add(view);
						pn2.add(JB_view);
						pn.add(pn1);
						pn.add(pn2);
						pn.setLayout(new FlowLayout());
								
						jframe.add(pn);
						jframe.setSize(800,800);
						jframe.validate();
								
				    	 JB_view.addActionListener(new ActionListener() {
							 @Override
							public void actionPerformed(ActionEvent e) 
							 { 
								JFrame jf=new JFrame("Payments Details");     
							    JTable jt;       
							    DefaultTableModel model = new DefaultTableModel(); 
							    jt= new JTable(model); 
							    model.addColumn("Payment Id");
							    model.addColumn("Cost");
							    model.addColumn("Rating");	
							    model.addColumn("Customer Id");
							    try 
							    {
									rs=stmt.executeQuery("select * from Payments");
									while(rs.next()) 
									{
										 model.addRow(new Object[]{rs.getString("payment_Id"),
												 rs.getString("cost"),rs.getString("rating"),rs.getString("customer_Id")});
									}
								}
								catch(SQLException exp) 
							    {
									displaySQLErrors(exp);
							    }
									
								jt.setEnabled(false);
						        jt.setBounds(30, 40, 180, 150); 
							    JScrollPane sp = new JScrollPane(jt);
							    jf.add(sp); 
							    jf.setSize(800, 400); 
							    jf.setVisible(true);        
						}   
					});	
				}
			});
		}
}
