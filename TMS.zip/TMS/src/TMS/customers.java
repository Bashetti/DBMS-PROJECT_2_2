//B.Sankeerthana 1602-19-737-099 ITS VACAY TIME TOUR MANAGEMENT SYSTEM
package TMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;

public class customers 
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_cus_id,JL_cus_name,JL_noOfPeople,JL_emailId,JL_phoneNo,JL_address;
	private JTextField JTF_cus_id,JTF_cus_name,JTF_noOfPeople,JTF_emailId,JTF_phoneNo,JTF_address;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert4,update4,view4,delete4;
	private List customersList;
	
	public customers(JPanel pn,JFrame jframe,JMenuItem insert4,JMenuItem update4,JMenuItem view4,JMenuItem delete4)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert4=insert4;
		this.update4=update4;
		this.view4=view4;
		this.delete4=delete4;
		
		JL_cus_id=new JLabel("Customer_Id:");
		JTF_cus_id=new JTextField(10);
		JL_cus_name=new JLabel("Customer Name:");
		JTF_cus_name=new JTextField(10);
        JL_noOfPeople=new JLabel("No Of People:");
        JTF_noOfPeople=new JTextField(10);
        JL_emailId=new JLabel("Email_Id:");
        JTF_emailId=new JTextField(10);
        JL_phoneNo=new JLabel("Phone No:");
        JTF_phoneNo=new JTextField(10);
        JL_address=new JLabel("Address:");
        JTF_address=new JTextField(10);
        
        this.pn=pn;
      //  jframe.add(pn);
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","it19737099","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadCustomers()
	{
		try
		{
			customersList.removeAll();
			rs=stmt.executeQuery("select * from Customers");
			while(rs.next()) 
			{
				customersList.add(rs.getString("customer_Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void buildGUI()
	{
		insert4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				
				JTF_cus_id.setText(null);
				JTF_cus_name.setText(null);
				JTF_noOfPeople.setText(null);
				JTF_emailId.setText(null);
				JTF_phoneNo.setText(null);
				JTF_address.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_cus_id);
				pn1.add(JTF_cus_id);
				pn1.add(JL_cus_name);
				pn1.add(JTF_cus_name);
				pn1.add(JL_noOfPeople);
				pn1.add(JTF_noOfPeople);
				pn1.add(JL_emailId);
				pn1.add(JTF_emailId);
				pn1.add(JL_phoneNo);
				pn1.add(JTF_phoneNo);
				pn1.add(JL_address);
				pn1.add(JTF_address);

				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,175,135);
				 
				pn2=new JPanel(new FlowLayout());
				customersList=new List(10);
				loadCustomers();
				pn2.add(customersList);
				pn2.setBounds(300,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO Customers VALUES(" + JTF_cus_id.getText() + ","
							+ "'" +JTF_cus_name.getText() +"'," +JTF_noOfPeople.getText() +","
							+"'"+JTF_emailId.getText() +"',"+JTF_phoneNo.getText()+",'"+JTF_address.getText()+"')";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadCustomers();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
		update4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_cus_id.setText(null);
				JTF_cus_name.setText(null);
				JTF_noOfPeople.setText(null);
				JTF_emailId.setText(null);
				JTF_phoneNo.setText(null);
				JTF_address.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_cus_id);
				pn1.add(JTF_cus_id);
				pn1.add(JL_cus_name);
				pn1.add(JTF_cus_name);
				pn1.add(JL_noOfPeople);
				pn1.add(JTF_noOfPeople);
				pn1.add(JL_emailId);
				pn1.add(JTF_emailId);
				pn1.add(JL_phoneNo);
				pn1.add(JTF_phoneNo);
				pn1.add(JL_address);
				pn1.add(JTF_address);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				customersList=new List(10);
				loadCustomers();
				pn2.add(customersList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				customersList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from customers");
							while (rs.next()) 
							{
								if (rs.getString("customer_id").equals(customersList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_cus_id.setText(rs.getString("customer_id"));
								JTF_cus_name.setText(rs.getString("customer_Name"));
								JTF_noOfPeople.setText(rs.getString("no_Of_People")); 
								JTF_emailId.setText(rs.getString("emailId"));
								JTF_phoneNo.setText(rs.getString("phone_No")); 
								JTF_address.setText(rs.getString("address"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure do you want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String pack=JOptionPane.showInputDialog(pn,"Enter no of people:");
								JTF_noOfPeople.setText(pack);
								String query="UPDATE Customers set no_Of_People='"+pack+"' where customer_Id="+JTF_cus_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows succesfully");
								loadCustomers();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		delete4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");
				
				JTF_cus_id.setText(null);
				JTF_cus_name.setText(null);
				JTF_noOfPeople.setText(null);
				JTF_emailId.setText(null);
				JTF_phoneNo.setText(null);
				JTF_address.setText(null);

				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_cus_id);
				pn1.add(JTF_cus_id);
				pn1.add(JL_cus_name);
				pn1.add(JTF_cus_name);
				pn1.add(JL_noOfPeople);
				pn1.add(JTF_noOfPeople);
				pn1.add(JL_emailId);
				pn1.add(JTF_emailId);
				pn1.add(JL_phoneNo);
				pn1.add(JTF_phoneNo);
				pn1.add(JL_address);
				pn1.add(JTF_address);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				customersList=new List(10);
				loadCustomers();
				pn2.add(customersList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				customersList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from customers");
							while (rs.next()) 
							{
								if (rs.getString("customer_id").equals(customersList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_cus_id.setText(rs.getString("customer_id"));
								JTF_cus_name.setText(rs.getString("customer_name"));
								JTF_noOfPeople.setText(rs.getString("no_Of_People")); 
								JTF_emailId.setText(rs.getString("emailId"));
								JTF_phoneNo.setText(rs.getString("phone_No")); 
								JTF_address.setText(rs.getString("address"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure do you want to Delete:");
							if(a==JOptionPane.YES_OPTION)
							{  
								//String query="DELETE FROM STATES WHERE state_Id="+statesList.getSelectedItem();
								String query="DELETE FROM Customers WHERE customer_Id="+JTF_cus_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows successfully");
								loadCustomers();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		view4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JLabel view=new JLabel("Customers View");
				JB_view=new JButton("View");
				Font myFont = new Font("Serif",Font.BOLD,50);
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn.add(pn1);
				pn.add(pn2);
				pn.setBounds(500,800,300,300);
				pn.setLayout(new FlowLayout());
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("Customers Details");
						JTable jt;
						DefaultTableModel model = new DefaultTableModel(); 
				        jt = new JTable(model); 
				        model.addColumn("Customer_ID");
				        model.addColumn("Customer Name");
				        model.addColumn("No Of People");
				        model.addColumn("Email Id");
				        model.addColumn("Phone No");
				        model.addColumn("Address");
					    try 
					    {		
							rs=stmt.executeQuery("select * from Customers");
							while(rs.next()) 
							{
								 model.addRow(new Object[]{rs.getString(1), 
								 rs.getString(2),rs.getString(3),rs.getString(4),
								 rs.getString(5),rs.getString(6)});
							}
						}
						catch(SQLException e) 
					    {
							displaySQLErrors(e);
						}
						jt.setEnabled(false);
				        jt.setBounds(30, 40, 300, 300); 
				        JScrollPane jsp = new JScrollPane(jt); 
				        jf.add(jsp); 
				        jf.setSize(800, 400); 
				        jf.setVisible(true); 
					}
				});	
			}
		});	
	}

}
