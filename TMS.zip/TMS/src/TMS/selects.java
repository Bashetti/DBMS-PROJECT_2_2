//B.Sankeerthana 1602-19-737-099 ITS VACAY TIME TOUR MANAGEMENT SYSTEM
package TMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;
import java.util.StringTokenizer;

public class selects 
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_selectYN,JL_cus_id,JL_vehicleType,JL_st_id;
	private JTextField JTF_st_id,JTF_selectYN,JTF_cus_id,JTF_vehicleType;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert6,update6,view6,delete6;
	private List selectsList;
	private Choice stateId,customerId;
	
	public selects(JPanel pn,JFrame jframe,JMenuItem insert6,JMenuItem update6,JMenuItem view6,JMenuItem delete6)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert6=insert6;
		this.update6=update6;
		this.view6=view6;
		this.delete6=delete6;
		
		JL_st_id=new JLabel("State_Id:");
		JTF_st_id=new JTextField(10);
		JL_cus_id=new JLabel("Customer Id:");
		JTF_cus_id=new JTextField(10);
		JL_selectYN=new JLabel("Select Yes Or No:");
        JTF_selectYN=new JTextField(10);
        JL_vehicleType=new JLabel("Vehicle Type:");
        JTF_vehicleType=new JTextField(10);
       
        this.pn=pn;
	}
    public void connectDatabase()
    {
    	try 
    	{
   			Connection con=DriverManager.getConnection(  
   			"jdbc:oracle:thin:@localhost:1521:xe","it19737099","vasavi");  
   			  
   			stmt=con.createStatement(); 
   			stmt.executeUpdate("commit");
    			
    	}
    	catch (SQLException connectException) 
   		{
   		  System.out.println(connectException.getMessage());
   		  System.out.println(connectException.getSQLState());
   		  System.out.println(connectException.getErrorCode());    		  
   		  System.exit(1);
    	}
    }
    private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
    public void loadSelects()
	{
		try
		{
			selectsList=new List();
			selectsList.removeAll();
			rs=stmt.executeQuery("select * from Selects");
			while(rs.next()) 
			{
				selectsList.add(rs.getString("state_Id")+"->"+rs.getString("customer_Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
    public void loadStates()
	{
		try
		{
			stateId=new Choice();
			stateId.removeAll();
			rs=stmt.executeQuery("select * from States");
			while(rs.next()) 
			{
				stateId.add(rs.getString("state_Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
    public void loadCustomers()
	{
		try
		{
			customerId=new Choice();
			customerId.removeAll();
			rs=stmt.executeQuery("select * from Customers");
			while(rs.next()) 
			{
				customerId.add(rs.getString("customer_Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
    public void buildGUI()
	{
		insert6.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				
				JTF_st_id.setText(null);
				JTF_cus_id.setText(null);
				JTF_selectYN.setText(null);
				JTF_vehicleType.setText(null);
				
				loadStates();
				loadCustomers();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_st_id);
				pn1.add(JTF_st_id);
				pn1.add(JL_cus_id);
				pn1.add(JTF_cus_id);
				pn1.add(JL_selectYN);
				pn1.add(JTF_selectYN);
				pn1.add(JL_vehicleType);
				pn1.add(JTF_vehicleType);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				
				pn2=new JPanel(new FlowLayout());
				selectsList=new List(10);
				loadSelects();
				pn2.add(selectsList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO Selects VALUES('"+ JTF_selectYN.getText() + "','"
							 +JTF_vehicleType.getText() +"'," +JTF_cus_id.getText()
							+","+JTF_st_id.getText() +")";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadSelects();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		update6.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_st_id.setText(null);
				JTF_cus_id.setText(null);
				JTF_selectYN.setText(null);
				JTF_vehicleType.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_st_id);
				pn1.add(JTF_st_id);
				pn1.add(JL_cus_id);
				pn1.add(JTF_cus_id);
				pn1.add(JL_selectYN);
				pn1.add(JTF_selectYN);
				pn1.add(JL_vehicleType);
				pn1.add(JTF_vehicleType);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				
				pn2=new JPanel(new FlowLayout());
				selectsList=new List(10);
				loadSelects();
				pn2.add(selectsList);
				pn2.setBounds(250,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				selectsList.addItemListener(new ItemListener() {
					@Override
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from Selects");
							while (rs.next()) 
							{
								if (rs.getString("state_Id").equals(selectsList.getSelectedItem()) && 
									rs.getString("customer_Id").equals(selectsList.getSelectedItem()))
									break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_selectYN.setText(rs.getString("selectYesOrNo"));
								JTF_vehicleType.setText(rs.getString("vehicle_Type"));
								JTF_cus_id.setText(rs.getString("customer_Id")); 
								JTF_st_id.setText(rs.getString("state_Id"));
 							 }
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							int a=JOptionPane.showConfirmDialog(pn1,"Are you sure do you want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String vehicleType=JOptionPane.showInputDialog(pn,"Enter New Vehicle Type:");
								JTF_vehicleType.setText(vehicleType);
								String query="update Selects set vehicle_Type='"+vehicleType+
								"' where customer_Id="+JTF_cus_id.getText()+" and state_Id="+JTF_st_id.getText();

								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows successfully");
								loadSelects();
							}
						}
						catch(SQLException exp)
						{
							displaySQLErrors(exp);
						}
					}
				});
			}
		});
		
		delete6.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");
				
				JTF_st_id.setText(null);
				JTF_cus_id.setText(null);
				JTF_selectYN.setText(null);
				JTF_vehicleType.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_st_id);
				pn1.add(JTF_st_id);
				pn1.add(JL_cus_id);
				pn1.add(JTF_cus_id);
				pn1.add(JL_selectYN);
				pn1.add(JTF_selectYN);
				pn1.add(JL_vehicleType);
				pn1.add(JTF_vehicleType);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(180,350,75,35);

				pn2=new JPanel(new FlowLayout());
				selectsList=new List(10);
				loadSelects();
				pn2.add(selectsList);
				pn2.setBounds(250,350,300,180);  
							
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				selectsList.addItemListener(new ItemListener() {
					@Override
					public void itemStateChanged(ItemEvent e)
					{
						try 
						{
							rs=stmt.executeQuery("select * from Selects");	
							while (rs.next()) 
							{													
								if (rs.getString("state_Id").equals(selectsList.getSelectedItem()) 
										&& rs.getString("customer_Id").equals(selectsList.getSelectedItem()))
								  break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_selectYN.setText(rs.getString("selectYesOrNo"));
								JTF_vehicleType.setText(rs.getString("vehicle_Type"));
								JTF_cus_id.setText(rs.getString("customer_Id"));
								JTF_st_id.setText(rs.getString("state_Id"));
							}
						}
						catch (SQLException selectException) 
						{
								displaySQLErrors(selectException);
						}
					}
				});
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure do you want to delete:");
							if(a==JOptionPane.YES_OPTION)
							 {  
								 StringTokenizer st=new StringTokenizer(selectsList.getSelectedItem(),"->");
								 String query="DELETE FROM Selects WHERE state_Id="+st.nextToken()+" and customer_Id="+st.nextToken();
							     int i=stmt.executeUpdate(query);
								 JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows successfully");
								 loadSelects();
							 }
						 }
						 catch(SQLException exp)
						 {
							 displaySQLErrors(exp);
						 }
					}
				});
			}
		});
		view6.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JB_view=new JButton("View");
				JLabel view=new JLabel("OverView On Data");
				Font myFont = new Font("Serif",Font.BOLD,50);
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn.add(pn1);
				pn.add(pn2);
				pn.setLayout(new FlowLayout());
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("Total Details");     
					    JTable jt;       
					    DefaultTableModel model = new DefaultTableModel(); 
					    
					    jt= new JTable(model); 
					    model.addColumn("State Id");
					    model.addColumn("Customer Id");
					    model.addColumn("Selects Yes Or No");	
					    model.addColumn("Vehicle_Type");
					    
					    try 
					    {
							rs=stmt.executeQuery("select * from Selects");
							while(rs.next()) 
							{
								 model.addRow(new Object[]{rs.getString(1), 
								rs.getString(2),rs.getString(3)
								,rs.getString(4)});
							}
						}
						catch(SQLException exp) 
					    {
							displaySQLErrors(exp);
					    }
					    jt.setEnabled(false);
				        jt.setBounds(30, 40, 180, 150); 
					    JScrollPane sp = new JScrollPane(jt);
					    jf.add(sp); 
					    jf.setSize(800, 400); 
					    jf.setVisible(true);        
					}
				});
			}
		});
	}        	
}
