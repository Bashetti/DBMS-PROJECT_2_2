//B.Sankeerthana 1602-19-737-099 ITS VACAY TIME TOUR MANAGEMENT SYSTEM
package TMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;

public class states 
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_st_name,JL_st_id,JL_st_package,JL_st_duration;
	private JTextField JTF_st_id,JTF_st_name,JTF_st_package,JTF_st_duration;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert1,update1,view1,delete1;
	private List statesList;
	
	public states(JPanel pn,JFrame jframe,JMenuItem insert1,JMenuItem update1,JMenuItem view1,JMenuItem delete1)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert1=insert1;
		this.update1=update1;
		this.view1=view1;
		this.delete1=delete1;
		
		JL_st_id=new JLabel("State_Id:");
		JTF_st_id=new JTextField(10);
		JL_st_name=new JLabel("State Name:");
		JTF_st_name=new JTextField(10);
        JL_st_package=new JLabel("Package:");
        JTF_st_package=new JTextField(10);
        JL_st_duration=new JLabel("Duration:");
        JTF_st_duration=new JTextField(10);

        
        this.pn=pn;
      
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","it19737099","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadStates()
	{
		try
		{
			statesList=new List();
			statesList.removeAll();
			rs=stmt.executeQuery("select * from States");
			while(rs.next()) 
			{
				statesList.add(rs.getString("state_Id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void buildGUI()
	{
		
		insert1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				
				JTF_st_id.setText(null);
				JTF_st_name.setText(null);
				JTF_st_package.setText(null);
				JTF_st_duration.setText(null);
				
				loadStates();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_st_id);
				pn1.add(JTF_st_id);
				pn1.add(JL_st_name);
				pn1.add(JTF_st_name);
				pn1.add(JL_st_package);
				pn1.add(JTF_st_package);
				pn1.add(JL_st_duration);
				pn1.add(JTF_st_duration);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				statesList=new List(10);
				loadStates();
				pn2.add(statesList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO States VALUES(" + JTF_st_id.getText() + ","
							+ "'" +JTF_st_name.getText() +"'," + "'"+JTF_st_package.getText() +"',"
							+JTF_st_duration.getText() +")";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadStates();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
		update1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_st_id.setText(null);
				JTF_st_name.setText(null);
				JTF_st_package.setText(null);
				JTF_st_duration.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_st_id);
				pn1.add(JTF_st_id);
				pn1.add(JL_st_name);
				pn1.add(JTF_st_name);
				pn1.add(JL_st_package);
				pn1.add(JTF_st_package);
				pn1.add(JL_st_duration);
				pn1.add(JTF_st_duration);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				statesList=new List(10);
				loadStates();
				pn2.add(statesList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				statesList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from states");
							while (rs.next()) 
							{
								if (rs.getString("state_id").equals(statesList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_st_id.setText(rs.getString("state_Id"));
								JTF_st_name.setText(rs.getString("state_Name"));
								JTF_st_package.setText(rs.getString("package")); 
								JTF_st_duration.setText(rs.getString("days"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String pack=JOptionPane.showInputDialog(pn,"Enter New Package:");
								JTF_st_package.setText(pack);
								String query="update states set package='"+pack+"' where state_Id="+JTF_st_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows succesfully");
								loadStates();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		delete1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");
				
				JTF_st_id.setText(null);
				JTF_st_name.setText(null);
				JTF_st_package.setText(null);
				JTF_st_duration.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_st_id);
				pn1.add(JTF_st_id);
				pn1.add(JL_st_name);
				pn1.add(JTF_st_name);
				pn1.add(JL_st_package);
				pn1.add(JTF_st_package);
				pn1.add(JL_st_duration);
				pn1.add(JTF_st_duration);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				statesList=new List(10);
				loadStates();
				pn2.add(statesList);
				pn2.setBounds(200,350,300,200);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				statesList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from states");
							while (rs.next()) 
							{
								if (rs.getString("state_id").equals(statesList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_st_id.setText(rs.getString("state_Id"));
								JTF_st_name.setText(rs.getString("state_Name"));
								JTF_st_package.setText(rs.getString("package")); 
								JTF_st_duration.setText(rs.getString("days"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to Delete:");
							if(a==JOptionPane.YES_OPTION)
							{  
								//String query="DELETE FROM STATES WHERE state_Id="+statesList.getSelectedItem();
								String query="DELETE FROM STATES WHERE state_Id="+JTF_st_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows succesfully");
								loadStates();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		view1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JLabel view=new JLabel("States View");
				JB_view=new JButton("View");
				Font myFont = new Font("Serif",Font.BOLD,50);
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn.add(pn1);
				pn.add(pn2);
				pn.setBounds(500,800,300,300);
				pn.setLayout(new FlowLayout());
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("States Details");
						JTable jt;
						DefaultTableModel model = new DefaultTableModel(); 
				        jt = new JTable(model); 
				        model.addColumn("State_ID");
				        model.addColumn("State Name");
				        model.addColumn("Package");
				        model.addColumn("Days");
					    try 
					    {		
							rs=stmt.executeQuery("select * from states");
							while(rs.next()) 
							{
								 model.addRow(new Object[]{rs.getInt(1), 
								 rs.getString(2),rs.getString(3),rs.getInt(4)});
							}
						}
						catch(SQLException e) 
					    {
							displaySQLErrors(e);
						}
						jt.setEnabled(false);
				        jt.setBounds(30, 40, 300, 300); 
				        JScrollPane jsp = new JScrollPane(jt); 
				        jf.add(jsp); 
				        jf.setSize(800, 400); 
				        jf.setVisible(true); 
					}
				});	
			}
		});	
	}
}
